@props(['size' => 38, 'class' => ''])
@php
    $uid = 'cst_' . substr(md5(uniqid('', true)), 0, 6);
@endphp
<svg viewBox="0 0 40 40" width="{{ $size }}" height="{{ $size }}" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" {{ $attributes->merge(['class' => 'shrink-0 ' . $class]) }}>
    <defs>
        <linearGradient id="{{ $uid }}_bg" x1="3" y1="3" x2="37" y2="37" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stop-color="#38bdf8"/>
            <stop offset="100%" stop-color="#2563eb"/>
        </linearGradient>
        <linearGradient id="{{ $uid }}_wave" x1="10" y1="26" x2="29" y2="13" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stop-color="#ffffff" stop-opacity="0.72"/>
            <stop offset="100%" stop-color="#ffffff" stop-opacity="1"/>
        </linearGradient>
    </defs>
    <rect x="2" y="2" width="36" height="36" rx="11" fill="url(#{{ $uid }}_bg)"/>
    <path d="M22.5 8.5C27.5 9.2 31.2 13 31.8 18" stroke="#ffffff" stroke-opacity="0.28" stroke-width="1.8" stroke-linecap="round"/>
    <path d="M10.5 25.5C14.8 25.5 16.2 19.6 20.2 20.4C23.6 21.1 25.4 16.4 29 13.2" stroke="url(#{{ $uid }}_wave)" stroke-width="2.7" stroke-linecap="round"/>
    <circle cx="29.2" cy="13" r="3" fill="#34d399" stroke="#ffffff" stroke-width="1.6"/>
</svg>
